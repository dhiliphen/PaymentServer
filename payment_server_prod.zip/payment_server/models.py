from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    orders = db.relationship("Order", back_populates="user")

class Product(db.Model):
    __tablename__ = "products"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=True)
    price_inr = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    orders = db.relationship("Order", back_populates="product")

class Order(db.Model):
    __tablename__ = "orders"
    id = db.Column(db.Integer, primary_key=True)
    razorpay_order_id = db.Column(db.String(64), index=True)
    razorpay_payment_id = db.Column(db.String(64), index=True)
    razorpay_signature = db.Column(db.String(255))
    status = db.Column(db.String(32), default="created")
    amount_paise = db.Column(db.Integer, nullable=False)
    currency = db.Column(db.String(8), default="INR")
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    user = db.relationship("User", back_populates="orders")
    product = db.relationship("Product", back_populates="orders")
    receipt = db.Column(db.String(64))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
