import os
import uuid
import logging
from flask import Flask, render_template, request, redirect, url_for, flash
from models import db, User, Product, Order
from config import Config
import razorpay


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)
    app.razorpay_client = razorpay.Client(
        auth=(app.config["RAZORPAY_KEY_ID"], app.config["RAZORPAY_KEY_SECRET"]))

    # Production logging
    if not app.debug:
        logging.basicConfig(level=logging.INFO)
        handler = logging.StreamHandler()
        handler.setLevel(logging.INFO)
        app.logger.addHandler(handler)

    @app.route("/")
    def index():
        products = Product.query.order_by(Product.id).all()
        return render_template("index.html", products=products, key_id=app.config["RAZORPAY_KEY_ID"])

    @app.post("/buy/<int:product_id>")
    def buy(product_id):
        name = request.form.get("name", "Guest")
        email = request.form.get("email", None)
        if not email:
            flash("Email is required to proceed to payment.", "error")
            return redirect(url_for("index"))

        user = User.query.filter_by(email=email).first()
        if not user:
            user = User(name=name, email=email)
            db.session.add(user)
            db.session.commit()

        product = Product.query.get_or_404(product_id)
        amount_paise = product.price_inr * 100
        receipt = f"rcpt_{uuid.uuid4().hex[:10]}"
        order = app.razorpay_client.order.create({
            "amount": amount_paise,
            "currency": "INR",
            "receipt": receipt,
            "payment_capture": 1,
        })

        o = Order(razorpay_order_id=order["id"], amount_paise=amount_paise, currency="INR", status="created",
                  user_id=user.id, product_id=product.id, receipt=receipt)
        db.session.add(o)
        db.session.commit()

        return render_template("checkout.html", product=product, user=user, amount_paise=amount_paise,
                               order_id=order["id"], key_id=app.config["RAZORPAY_KEY_ID"])

    @app.post("/payment/verify")
    def payment_verify():
        rp_order_id = request.form.get("razorpay_order_id")
        rp_payment_id = request.form.get("razorpay_payment_id")
        rp_signature = request.form.get("razorpay_signature")

        if not (rp_order_id and rp_payment_id and rp_signature):
            flash("Missing payment verification fields.", "error")
            return redirect(url_for("index"))

        try:
            util = razorpay.Utility()
            util.verify_payment_signature({
                "razorpay_order_id": rp_order_id,
                "razorpay_payment_id": rp_payment_id,
                "razorpay_signature": rp_signature,
            })
            verified = True
        except razorpay.errors.SignatureVerificationError:
            verified = False

        order = Order.query.filter_by(razorpay_order_id=rp_order_id).first()
        if not order:
            flash("Order not found in DB.", "error")
            return redirect(url_for("index"))

        order.razorpay_payment_id = rp_payment_id
        order.razorpay_signature = rp_signature
        order.status = "paid" if verified else "failed"
        db.session.commit()

        return render_template("success.html" if verified else "failure.html", order=order)

    return app


app = create_app()

# Only for local development. Use a WSGI server like Gunicorn or uWSGI in production.
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
