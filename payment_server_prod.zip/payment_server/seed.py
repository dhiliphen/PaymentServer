from app import create_app
from models import db, Product, User

app = create_app()

with app.app_context():
    db.drop_all()
    db.create_all()
    p1 = Product(name="Pro License", description="1-year Pro license", price_inr=1999)
    p2 = Product(name="Starter License", description="6-month Starter license", price_inr=999)
    u1 = User(name="Demo User", email="demo@example.com")
    db.session.add_all([p1, p2, u1])
    db.session.commit()
    print("Seeded products and a demo user.")
